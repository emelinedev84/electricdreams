package com.devnoir.electricdreams.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.devnoir.electricdreams.dto.TagPublicDTO;
import com.devnoir.electricdreams.enums.Language;
import com.devnoir.electricdreams.repositories.TagRepository;

@Service
public class BlogTagService {

	@Autowired
	private TagRepository tagRepository;
	
	@Transactional(readOnly = true)
    public List<TagPublicDTO> findAll(Language language) {
        return tagRepository.findAll().stream()
                .map(c -> new TagPublicDTO(
                        c.getCode(),
                        c.getLocalizedName(language)  // ou helper
                ))
                .toList();
    }
}