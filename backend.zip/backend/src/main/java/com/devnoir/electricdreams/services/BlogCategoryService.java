package com.devnoir.electricdreams.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.devnoir.electricdreams.dto.CategoryPublicDTO;
import com.devnoir.electricdreams.enums.Language;
import com.devnoir.electricdreams.repositories.CategoryRepository;

@Service
public class BlogCategoryService {

	@Autowired
	private CategoryRepository categoryRepository;
	
	@Transactional(readOnly = true)
    public List<CategoryPublicDTO> findAll(Language language) {
        return categoryRepository.findAll().stream()
                .map(c -> new CategoryPublicDTO(
                        c.getCode(),
                        c.getLocalizedName(language)  // ou helper
                ))
                .toList();
    }
}