package com.devnoir.electricdreams.resources;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.devnoir.electricdreams.dto.TagPublicDTO;
import com.devnoir.electricdreams.enums.Language;
import com.devnoir.electricdreams.services.BlogTagService;

@RestController
@RequestMapping(value = "/{language}/tags")
public class BlogTagResource {

	@Autowired
	public BlogTagService tagService;
	
	@GetMapping
	public ResponseEntity<List<TagPublicDTO>> findAll(@PathVariable Language language, Pageable pageable) {
		List<TagPublicDTO> list = tagService.findAll(language);
		return ResponseEntity.ok().body(list);
	}
}