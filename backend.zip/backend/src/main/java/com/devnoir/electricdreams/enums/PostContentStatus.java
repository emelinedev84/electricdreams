package com.devnoir.electricdreams.enums;

public enum PostContentStatus {
	DRAFT,
	PUBLISHED
}
