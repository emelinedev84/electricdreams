package com.devnoir.electricdreams.resources;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.devnoir.electricdreams.dto.CategoryPublicDTO;
import com.devnoir.electricdreams.enums.Language;
import com.devnoir.electricdreams.services.BlogCategoryService;

@RestController
@RequestMapping(value = "/{language}/categories")
public class BlogCategoryResource {

	@Autowired
	public BlogCategoryService categoryService;
	
	@GetMapping
	public ResponseEntity<List<CategoryPublicDTO>> findAll(@PathVariable Language language, Pageable pageable) {
		List<CategoryPublicDTO> list = categoryService.findAll(language);
		return ResponseEntity.ok().body(list);
	}
}