package com.devnoir.electricdreams.services;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.devnoir.electricdreams.dto.CategoryDTO;
import com.devnoir.electricdreams.dto.PostCreateDTO;
import com.devnoir.electricdreams.dto.PostDTO;
import com.devnoir.electricdreams.dto.PostSummaryDTO;
import com.devnoir.electricdreams.dto.TagDTO;
import com.devnoir.electricdreams.entities.Category;
import com.devnoir.electricdreams.entities.Post;
import com.devnoir.electricdreams.entities.PostContent;
import com.devnoir.electricdreams.entities.Tag;
import com.devnoir.electricdreams.entities.User;
import com.devnoir.electricdreams.enums.Language;
import com.devnoir.electricdreams.repositories.CategoryRepository;
import com.devnoir.electricdreams.repositories.PostRepository;
import com.devnoir.electricdreams.repositories.TagRepository;
import com.devnoir.electricdreams.repositories.UserRepository;
import com.devnoir.electricdreams.services.exceptions.BusinessException;
import com.devnoir.electricdreams.services.exceptions.DatabaseException;
import com.devnoir.electricdreams.services.exceptions.ResourceNotFoundException;

@Service
public class AdminPostService {

	@Autowired
	private PostRepository postRepository;
 	
 	@Autowired
 	private UserRepository userRepository;
 	
 	@Autowired
 	private TagRepository tagRepository;
 	
 	@Autowired
 	private CategoryRepository categoryRepository;
 	
 	@Autowired
 	private UrlHandleService urlHandleService;
 	
 	@Transactional(readOnly = true)
 	public Page<PostSummaryDTO> findAllSummary(Pageable pageable) {
 		Page<Post> page = postRepository.findAll(pageable);
 		return page.map(x -> new PostSummaryDTO(x));
 	}
 	
 	@Transactional(readOnly = true) 
 	public PostDTO findById(Long id) {
 	    Post post = postRepository.findByIdWithContentsTagsAndCategories(id).orElseThrow(() -> new ResourceNotFoundException("Post not found")); 
 	    return new PostDTO(post);
 	}
 	
 	@Transactional
 	public PostDTO create(PostCreateDTO dto) {
  	    Post post = new Post();
 	    
 	    post.setImageUrl(dto.getImageUrl());
        User user = userRepository.findById(dto.getAuthorId())
                .orElseThrow(() -> new ResourceNotFoundException("Author not found: " + dto.getAuthorId()));
        post.setAuthor(user);
       
        if (dto.getEn() != null) {
            PostContent newContent = new PostContent();
            newContent.setPost(post);
            newContent.setLanguage(Language.EN);
            
            if (newContent.getUrlHandle() == null || newContent.getUrlHandle().isBlank()) {
                newContent.setUrlHandle(urlHandleService.generateUniqueHandle(dto.getEn().getTitle(), Language.EN));
            }
            
            newContent.setTitle(dto.getEn().getTitle());
            newContent.setContent(dto.getEn().getContent());
            newContent.setMetaDescription(dto.getEn().getMetaDescription());
            newContent.setStatus(dto.getEn().getStatus()); 
            newContent.setPost(post);
            
            if (!post.getContents().contains(newContent)) {
                post.getContents().add(newContent);
            }
        }
        if (dto.getPt() != null) {
            PostContent newContent = new PostContent();
            newContent.setPost(post);
            newContent.setLanguage(Language.PT);
            
            if (newContent.getUrlHandle() == null || newContent.getUrlHandle().isBlank()) {
                newContent.setUrlHandle(urlHandleService.generateUniqueHandle(dto.getPt().getTitle(), Language.PT));
            }
            
            newContent.setTitle(dto.getPt().getTitle());
            newContent.setContent(dto.getPt().getContent());
            newContent.setMetaDescription(dto.getPt().getMetaDescription());
            newContent.setStatus(dto.getPt().getStatus()); 
            newContent.setPost(post);
            
            if (!post.getContents().contains(newContent)) {
                post.getContents().add(newContent);
            }
        }        
        Set<TagDTO> tags = new HashSet<>();
        for (TagDTO tagDto : dto.getTags()) {
            if (!tags.add(tagDto)) {
                throw new BusinessException("Duplicate tag in this post: " + tagDto.getCode());
            }
            Tag tag = tagRepository.findById(tagDto.getId()).orElseThrow(() -> new ResourceNotFoundException("Tag not found: " + tagDto.getId()));
            post.getTags().add(tag);
        }
        
        Set<CategoryDTO> categories = new HashSet<>();
        for (CategoryDTO categoryDto : dto.getCategories()) {
            if (!categories.add(categoryDto)) {
                throw new BusinessException("Duplicate category in this post: " + categoryDto.getCode());
            }
            Category category = categoryRepository.findById(categoryDto.getId()).orElseThrow(() -> new ResourceNotFoundException("Category not found: " + categoryDto.getId()));
            post.getCategories().add(category);
        }
       
        postRepository.save(post);
 	    
 	    
 	    Post savedPost = postRepository.findByIdWithContentsTagsAndCategories(post.getId())
 	        .orElseThrow(() -> new ResourceNotFoundException("Post not found"));
 	    return new PostDTO(savedPost);
 	}
 	
 	@Transactional
 	public PostDTO update(Long id, PostCreateDTO dto) {
		
 	    Post post = postRepository.findById(id)
 	        .orElseThrow(() -> new ResourceNotFoundException("Post not found: " + id));

 	    post.setImageUrl(dto.getImageUrl());
        User user = userRepository.findById(dto.getAuthorId())
                .orElseThrow(() -> new ResourceNotFoundException("Author not found: " + dto.getAuthorId()));
        post.setAuthor(user);
      
        if (dto.getEn() != null) {
            PostContent newContent = new PostContent();
            newContent.setPost(post);
            newContent.setLanguage(Language.EN);
           
            if (newContent.getUrlHandle() == null || newContent.getUrlHandle().isBlank()) {
                newContent.setUrlHandle(urlHandleService.generateUniqueHandle(dto.getEn().getTitle(), Language.EN));
            }
           
            newContent.setTitle(dto.getEn().getTitle());
            newContent.setContent(dto.getEn().getContent());
            newContent.setMetaDescription(dto.getEn().getMetaDescription());
            newContent.setStatus(dto.getEn().getStatus()); 
            newContent.setPost(post);
           
            if (!post.getContents().contains(newContent)) {
                post.getContents().add(newContent);
            }
        }
        if (dto.getPt() != null) {
            PostContent newContent = new PostContent();
            newContent.setPost(post);
            newContent.setLanguage(Language.PT);
           
            if (newContent.getUrlHandle() == null || newContent.getUrlHandle().isBlank()) {
                newContent.setUrlHandle(urlHandleService.generateUniqueHandle(dto.getPt().getTitle(), Language.PT));
            }
           
            newContent.setTitle(dto.getPt().getTitle());
            newContent.setContent(dto.getPt().getContent());
            newContent.setMetaDescription(dto.getPt().getMetaDescription());
            newContent.setStatus(dto.getPt().getStatus()); 
            newContent.setPost(post);
           
            if (!post.getContents().contains(newContent)) {
                post.getContents().add(newContent);
            }
        }        
        
        updatePostCategories(post, dto);
        updatePostTags(post, dto);
      
        postRepository.save(post);

 	    Post updatedPost = postRepository.findByIdWithContentsTagsAndCategories(post.getId())
 	        .orElseThrow(() -> new ResourceNotFoundException("Post not found"));
 	    return new PostDTO(updatedPost);
 	}
 	
 	@Transactional(propagation = Propagation.SUPPORTS)
 	public void deletePost(Long id) {
 		try {
 			Post post = postRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Post not found: " + id));
 			postRepository.delete(post);
 		} catch (DataIntegrityViolationException e) {
 			throw new DatabaseException("Integrity violation");
 		}
 	}
 	
 	@Transactional(propagation = Propagation.SUPPORTS)
	public void deletePostContent(Long id, String language) {
 	    try {
 	        Post post = postRepository.findByIdWithContents(id)
 	            .orElseThrow(() -> new ResourceNotFoundException("Post not found"));
 	            
 	        Language lang = Language.valueOf(language.toUpperCase());
 	        
 	        boolean removed = post.getContents().removeIf(content -> content.getLanguage() == lang);
 	        
 	        if (!removed) {
 	            throw new ResourceNotFoundException("Content not found for language: " + language);
 	        }
 	        
 	        if (post.getContents().isEmpty()) {
 	            postRepository.delete(post);
 	        } else {
 	            postRepository.save(post);
 	        }
 	    } catch (DataIntegrityViolationException e) {
 	        throw new DatabaseException("Integrity violation");
 	    }
	}
 	 	
 	private void updatePostTags(Post post, PostCreateDTO dto) {
        post.getTags().clear();
        if (dto.getTags() != null) {
            Set<TagDTO> tags = new HashSet<>();
            for (TagDTO tagDto : dto.getTags()) {
                if (!tags.add(tagDto)) {
                    throw new BusinessException("Duplicate tag in this post: " + tagDto.getCode());
                }
                Tag tag = tagRepository.findById(tagDto.getId()).orElseThrow(() -> new ResourceNotFoundException("Tag not found: " + tagDto.getId()));
                post.getTags().add(tag);
            }
        }
    }

    private void updatePostCategories(Post post, PostCreateDTO dto) {
        post.getCategories().clear();
        if (dto.getCategories() != null) {
            Set<CategoryDTO> categories = new HashSet<>();
            for (CategoryDTO categoryDto : dto.getCategories()) {
                if (!categories.add(categoryDto)) {
                    throw new BusinessException("Duplicate category in this post: " + categoryDto.getCode());
                }
                Category category = categoryRepository.findById(categoryDto.getId()).orElseThrow(() -> new ResourceNotFoundException("Category not found: " + categoryDto.getId()));
                post.getCategories().add(category);
            }
        }
    }
}