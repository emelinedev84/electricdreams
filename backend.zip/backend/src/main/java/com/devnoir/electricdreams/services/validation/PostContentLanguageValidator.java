package com.devnoir.electricdreams.services.validation;

import org.springframework.stereotype.Component;

import com.devnoir.electricdreams.dto.PostCreateDTO;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

@Component
public class PostContentLanguageValidator implements ConstraintValidator<PostContentLanguageValid, PostCreateDTO> {

	@Override
	public boolean isValid(PostCreateDTO dto, ConstraintValidatorContext context) {
		if (dto == null) {
			return true;
		}

		boolean isValid = true;
		context.disableDefaultConstraintViolation();

		// Check if at least one language is provided
		if (dto.getEn() == null && dto.getPt() == null) {
			context.buildConstraintViolationWithTemplate("At least one language content (EN or PT) is required")
				.addConstraintViolation();
			return false;
		}

		return isValid;
	}
}